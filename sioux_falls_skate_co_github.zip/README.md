# Sioux Falls Skate Co. Website

This is the official Sioux Falls Skate Co. multi-page website built in HTML and styled with graffiti-inspired visuals.

## 📂 Pages Included
- index.html (Home)
- merch.html
- decks.html
- grip.html
- wheels.html
- trucks.html
- contact.html

## 🚀 How to Publish on GitHub Pages

1. Go to [GitHub](https://github.com) and create a new public repository.
2. Upload all files from this ZIP (ensure index.html is in the root folder).
3. Commit your changes.
4. In your repository, go to **Settings → Pages**.
5. Under **Source**, select the **main branch**, then click **Save**.
6. After 1–2 minutes, your website will be live at:

   `https://your-username.github.io/sioux-falls-skate-co/`

---

Created for Sioux Falls Skate Co.
