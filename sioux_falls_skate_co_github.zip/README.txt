
Sioux Decks — Multi-page website
Files:
- index.html (Home)
- merch.html
- decks.html
- griptape.html
- wheels.html
- trucks.html
- contact.html

To preview locally: open index.html in your browser.
To host on GitHub Pages: push these files to a repository's root (or gh-pages branch) and enable Pages.
This package uses Unsplash images (hotlinked). For production, download and host images or replace with your assets.
